/*
    1. Create a file named as "colors.txt" and add 50 randomly generated colors to it
    2. Create a file named as "prime.log" and add only prime numbers from 1 to 1000
    3. Create a file named as "os.txt" and add free memory of the os after every 10s (should happen infinitely)
*/

