let arr = []
let obj = {
    "Hello":"World"
}
arr.push(obj)
console.log(arr)