import React from 'react'
export default function Display({fname}) {
  return (
    <div>
      {fname} <br /><br />
    </div>
  )
}
