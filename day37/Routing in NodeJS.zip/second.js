import * as index from "./index.js";
console.log(index.hello, index.myFunc())