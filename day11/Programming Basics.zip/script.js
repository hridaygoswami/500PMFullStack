// console.log("Hello world")
// let, const, var

// int, float, str, bool -> primitive datatypes

// let a = 10 // datatype -> integer
// // int a = 10
// console.log(a)
// a = 10.5
// console.log(a)
// a = 'Hriday'
// console.log(a)
// a = true
// console.log(a)

// console.log("Hello world")
// console.log("How are you?")

// console.log("hello world.\n \t \\How are you?")
// "use strict";
// a = 10
// b = 10
// console.log("The value of a is", a, "\nThe value of b is", b)
// console.log(`The value of a is ${a+b}`)

// let a = 10
// console.log(a)
// {   
    // var a = 20
    // console.log(a)
// }
// a = 30
// console.log(a)

// Typecasting

// let a = '10'
// console.log(typeof((a)))

let a = prompt('Enter your name: ')
console.log(a)